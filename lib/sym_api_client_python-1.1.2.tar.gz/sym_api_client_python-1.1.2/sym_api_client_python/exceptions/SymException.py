class SymException(Exception):
    pass
