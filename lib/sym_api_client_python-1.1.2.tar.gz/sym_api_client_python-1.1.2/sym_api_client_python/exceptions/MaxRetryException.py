class MaxRetryException(Exception):
    pass
