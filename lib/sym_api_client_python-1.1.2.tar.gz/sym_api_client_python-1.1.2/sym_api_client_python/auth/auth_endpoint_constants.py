auth_endpoint_constants = {

    "WAIT_TIME" : 30000,
    "TIMEOUT" : 30,
    "MAX_RSA_RETRY" : 5,
    "MAX_AUTH_RETRY": 5

}
